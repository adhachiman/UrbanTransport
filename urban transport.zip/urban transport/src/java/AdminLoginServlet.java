import DAO.AdminDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Admin;

// Mapping for the Servlet
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validate admin and retrieve admin object
        Admin admin = AdminDAO.validateAdmin(email, password);

        if (admin != null) {
            // If admin exists, store admin details in session
            HttpSession session = request.getSession();
            session.setAttribute("loggedInAdmin", admin);
            session.setAttribute("adminEmail", email);
            session.setAttribute("adminId", admin.getAdminId()); // Store admin ID in session

            // Redirect to admin dashboard
            response.sendRedirect("AdminDashboardServlet");
        } else {
            // If invalid credentials, show error message
            response.getWriter().println("<script type='text/javascript'>");
            response.getWriter().println("alert('Invalid credentials! Try again or Register');");
            response.getWriter().println("window.location.href='adminLogin.jsp';"); 
            response.getWriter().println("</script>");
        }
    }
}

