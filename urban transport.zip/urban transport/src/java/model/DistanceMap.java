/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class DistanceMap {
    private int mapId;
    private String placeA;
    private String placeB;
    private double distancePlace;

    // Getters and Setters
    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public String getPlaceA() {
        return placeA;
    }

    public void setPlaceA(String placeA) {
        this.placeA = placeA;
    }

    public String getPlaceB() {
        return placeB;
    }

    public void setPlaceB(String placeB) {
        this.placeB = placeB;
    }

    public double getDistancePlace() {
        return distancePlace;
    }

    public void setDistancePlace(double distancePlace) {
        this.distancePlace = distancePlace;
    }
}

