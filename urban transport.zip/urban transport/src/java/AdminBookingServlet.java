import DAO.BookingDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Booking;

@WebServlet("/AdminBookingServlet")
public class AdminBookingServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Booking> bookings = BookingDAO.getAllBookings(); // Fetch all bookings
        
        request.setAttribute("bookings", bookings);
        request.getRequestDispatcher("adminBookings.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String bookingIdStr = request.getParameter("booking_id");

        try {
            int bookingId = Integer.parseInt(bookingIdStr);

            if ("update".equals(action)) {
                String status = request.getParameter("status");
                if (BookingDAO.updateBookingStatus(bookingId, status)) {
                    response.sendRedirect("AdminBookingServlet");  // Redirect to refresh data
                } else {
                    request.setAttribute("message", "Failed to update the booking status.");
                    request.getRequestDispatcher("adminBookings.jsp").forward(request, response);
                }
            } else if ("delete".equals(action)) {
                if (BookingDAO.deleteBooking(bookingId)) {
                    response.sendRedirect("AdminBookingServlet"); // Refresh the list after deletion
                } else {
                    request.setAttribute("message", "Failed to delete the booking.");
                    request.getRequestDispatcher("adminBookings.jsp").forward(request, response);
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("message", "Invalid booking ID.");
            request.getRequestDispatcher("adminBookings.jsp").forward(request, response);
        }
    }
}
