import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/adminDashboard")
public class AdminDashboardServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:derby://localhost:1527/vehicle_booking";
    private static final String DB_USER = "app";
    private static final String DB_PASSWORD = "app";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if admin is logged in
        HttpSession session = request.getSession();
        Integer adminId = (Integer) session.getAttribute("adminId");

        if (adminId == null) {
            // If not logged in, redirect to admin login page
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        String adminName = null; // To store admin's name
        int totalCustomers = 0;
        int totalAdmins = 0;
        int totalVehicles = 0;
        int totalBookings = 0;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Retrieve admin name from database
            String adminQuery = "SELECT fullname FROM admin WHERE admin_id = ?";
            PreparedStatement psAdmin = conn.prepareStatement(adminQuery);
            psAdmin.setInt(1, adminId);
            ResultSet rsAdmin = psAdmin.executeQuery();
            if (rsAdmin.next()) {
                adminName = rsAdmin.getString("fullname");
            }

            // Store the admin name in session for reuse
            session.setAttribute("adminName", adminName);

            // Get total customers
            String customersQuery = "SELECT COUNT(*) FROM customer";
            PreparedStatement ps1 = conn.prepareStatement(customersQuery);
            ResultSet rs1 = ps1.executeQuery();
            if (rs1.next()) {
                totalCustomers = rs1.getInt(1);
            }

            // Get total admins
            String adminsQuery = "SELECT COUNT(*) FROM admin";
            PreparedStatement ps2 = conn.prepareStatement(adminsQuery);
            ResultSet rs2 = ps2.executeQuery();
            if (rs2.next()) {
                totalAdmins = rs2.getInt(1);
            }

            // Get total vehicles
            String vehiclesQuery = "SELECT COUNT(*) FROM vehicle";
            PreparedStatement ps3 = conn.prepareStatement(vehiclesQuery);
            ResultSet rs3 = ps3.executeQuery();
            if (rs3.next()) {
                totalVehicles = rs3.getInt(1);
            }

            // Get total bookings
            String bookingsQuery = "SELECT COUNT(*) FROM booking";
            PreparedStatement ps4 = conn.prepareStatement(bookingsQuery);
            ResultSet rs4 = ps4.executeQuery();
            if (rs4.next()) {
                totalBookings = rs4.getInt(1);
            }

            // Set attributes for the JSP
            request.setAttribute("adminName", adminName);  // Set the admin name
            request.setAttribute("totalCustomers", totalCustomers);
            request.setAttribute("totalAdmins", totalAdmins);
            request.setAttribute("totalVehicles", totalVehicles);
            request.setAttribute("totalBookings", totalBookings);

            // Forward to the admin dashboard JSP
            request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching or updating dashboard data.");
        }
    }
}
