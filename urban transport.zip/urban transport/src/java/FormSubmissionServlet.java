import DAO.BookingDAO;
import DAO.CustomerDAO;
import DAO.VehicleDAO;
import DAO.DistanceMapDAO;
import model.Booking;
import model.Vehicle;
import model.DistanceMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import model.Customer;

@WebServlet("/formSubmission")
public class FormSubmissionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
            Vehicle vehicle = VehicleDAO.getVehicleById(vehicleId);

            if (vehicle == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Vehicle not found");
                return;
            }
            
            // Get the customer ID from the session
        HttpSession session = request.getSession();
        Integer customerId = (Integer) session.getAttribute("customerId"); // Retrieve customer ID from session

        // If the customer is not logged in, redirect to login page
        if (customerId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Fetch customer information from DAO using the customerId
        Customer customer = CustomerDAO.getCustomerById(customerId);

        // If customer is not found, redirect to login page
        if (customer == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Set the customer object as a request attribute
        request.setAttribute("customer", customer);
            
           

            // Fetch distance map entries for the table
            List<DistanceMap> distanceMaps = DistanceMapDAO.getAllDistances();
            if (distanceMaps == null || distanceMaps.isEmpty()) {
                System.out.println("No distance maps found in the database."); // Debugging log
                request.setAttribute("distanceMaps", new ArrayList<>()); // Set empty list to avoid null
            } else {
                System.out.println("Distance maps fetched: " + distanceMaps); // Debugging log
                request.setAttribute("distanceMaps", distanceMaps);
            }

            request.setAttribute("vehicle", vehicle);
            request.getRequestDispatcher("customerFormSubmission.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid vehicle ID");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while fetching vehicle details");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Parse request parameters
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
            String pickupTimeStr = request.getParameter("pickupTime").replace("T", " ") + ":00";
            Timestamp pickupTime = Timestamp.valueOf(pickupTimeStr);

            // Parse the selected route (pickup, dropoff, distance)
            String pickupLocation = request.getParameter("pickupLocation");
            String dropoffLocation = request.getParameter("dropoffLocation");
            double distance = Double.parseDouble(request.getParameter("distance"));

            // Fetch vehicle details
            Vehicle vehicle = VehicleDAO.getVehicleById(vehicleId);
            if (vehicle == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Vehicle not found");
                return;
            }

            // Retrieve customer ID from session
            HttpSession session = request.getSession();
            Integer customerId = (Integer) session.getAttribute("customerId");
            if (customerId == null) {
                response.sendRedirect("index.html");
                return;
            }

            // Calculate total charge
            double totalCharge = distance * vehicle.getCharge();

            // Create a new booking object
            Booking booking = new Booking(customerId, vehicleId, pickupTime, pickupLocation, dropoffLocation, distance, totalCharge);

            // Save the booking to the database
            int bookingId = BookingDAO.addBooking(booking);

            // Redirect to the receipt servlet if booking is successful
            if (bookingId > 0) {
                response.sendRedirect("ReceiptServlet?bookingId=" + bookingId);
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to create booking");
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input data");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing the booking");
        }
    }
}
