/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DAO.DistanceMapDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DistanceCheckServlet")
public class DistanceCheckServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String pickup = request.getParameter("pickup");
        String dropoff = request.getParameter("dropoff");

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {
            if (pickup.equalsIgnoreCase(dropoff)) {
                response.getWriter().write("{\"success\": false, \"error\": \"Pickup and drop-off locations cannot be the same.\"}");
                return;
            }

            Double distance = DistanceMapDAO.getDistanceBetweenPlaces(pickup, dropoff);
            if (distance != null) {
                response.getWriter().write("{\"success\": true, \"distance\": " + distance + "}");
            } else {
                response.getWriter().write("{\"success\": false, \"error\": \"Locations not found in the database.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"success\": false, \"error\": \"An error occurred while checking the distance.\"}");
        }
    }
}
