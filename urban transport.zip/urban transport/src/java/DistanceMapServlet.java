import DAO.DistanceMapDAO;
import model.DistanceMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/DistanceMapServlet")
public class DistanceMapServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if admin is logged in
        HttpSession session = request.getSession();
        Integer adminId = (Integer) session.getAttribute("adminId");
        String adminName = (String) session.getAttribute("adminName");

        if (adminId == null) {
            // Redirect to admin login if not logged in
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        // Set admin name attribute for display in the JSP
        request.setAttribute("adminName", adminName);

        try {
            // Retrieve all distance map entries
            List<DistanceMap> distanceMaps = DistanceMapDAO.getAllDistances();
            request.setAttribute("distanceMaps", distanceMaps);
            request.getRequestDispatcher("distanceMap.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error fetching distance map data.", e);
        }
    }

     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if admin is logged in
        HttpSession session = request.getSession();
        Integer adminId = (Integer) session.getAttribute("adminId");
        String adminName = (String) session.getAttribute("adminName");

        if (adminId == null) {
            // Redirect to admin login if not logged in
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        // Set admin name attribute for display in the JSP
        request.setAttribute("adminName", adminName);

        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
                // Add a new distance map entry
                String placeA = request.getParameter("placeA");
                String placeB = request.getParameter("placeB");
                double distancePlace = Double.parseDouble(request.getParameter("distancePlace"));

                try {
                    DistanceMapDAO.addDistance(placeA, placeB, distancePlace);
                } catch (SQLException e) {
                    // Set the error message in the request if duplicate entry occurs
                    request.setAttribute("error", "Duplicate entry: The distance map between these places already exists.");
                    request.getRequestDispatcher("distanceMap.jsp").forward(request, response);
                    return;
                }

            } else if ("edit".equals(action)) {
                // Edit an existing distance map entry
                int mapId = Integer.parseInt(request.getParameter("mapId"));
                String placeA = request.getParameter("placeA");
                String placeB = request.getParameter("placeB");
                double distancePlace = Double.parseDouble(request.getParameter("distancePlace"));

                DistanceMap updatedMap = new DistanceMap();
                updatedMap.setMapId(mapId);
                updatedMap.setPlaceA(placeA);
                updatedMap.setPlaceB(placeB);
                updatedMap.setDistancePlace(distancePlace);

                DistanceMapDAO.updateDistance(updatedMap);

            } else if ("delete".equals(action)) {
                // Delete a distance map entry
                int mapId = Integer.parseInt(request.getParameter("mapId"));
                DistanceMapDAO.deleteDistance(mapId);
            }

            // Redirect back to refresh the list
            response.sendRedirect("DistanceMapServlet");

        } catch (SQLException e) {
            throw new ServletException("Error processing the distance map request.", e);
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid input provided.");
            request.getRequestDispatcher("distanceMap.jsp").forward(request, response);
        }
    }
}
