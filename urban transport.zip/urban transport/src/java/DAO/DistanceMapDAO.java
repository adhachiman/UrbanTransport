package DAO;

import model.DistanceMap;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DistanceMapDAO {
    private static final String DB_URL = "jdbc:derby://localhost:1527/vehicle_booking";
    private static final String DB_USER = "app";  // Default user for JavaDB
    private static final String DB_PASSWORD = "app";  // Default password

    // Method to get a connection (to avoid repeating code every time)
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    // Add a new distance map entry
    public static void addDistance(String placeA, String placeB, double distancePlace) throws SQLException {
        // Check for duplicates before inserting
        if (isDuplicateEntry(placeA, placeB)) {
            throw new SQLException("Duplicate entry: The distance map between these places already exists.");
        }
        
        String query = "INSERT INTO distance_map (place_a, place_b, distance_place) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, placeA);
            ps.setString(2, placeB);
            ps.setDouble(3, distancePlace);
            ps.executeUpdate();
        }
    }

    // Method to check for duplicate entries
    public static boolean isDuplicateEntry(String placeA, String placeB) throws SQLException {
        String query = "SELECT 1 FROM distance_map WHERE (place_a = ? AND place_b = ?) OR (place_a = ? AND place_b = ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, placeA);
            ps.setString(2, placeB);
            ps.setString(3, placeB);
            ps.setString(4, placeA);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();  // If there is a result, it's a duplicate
            }
        }
    }

    // Retrieve all entries
    public static List<DistanceMap> getAllDistances() throws SQLException {
        List<DistanceMap> distances = new ArrayList<>();
        String query = "SELECT * FROM distance_map";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                DistanceMap map = new DistanceMap();
                map.setMapId(rs.getInt("map_id"));
                map.setPlaceA(rs.getString("place_a"));
                map.setPlaceB(rs.getString("place_b"));
                map.setDistancePlace(rs.getDouble("distance_place"));
                distances.add(map);
            }
        }
        return distances;
    }

    // Delete an entry by ID, ensuring related records are deleted first
    public static void deleteDistance(int mapId) throws SQLException {
        String deleteDistanceMapQuery = "DELETE FROM distance_map WHERE map_id = ?";

        try (Connection conn = getConnection()) {

            // Delete the distance map entry
            try (PreparedStatement psDistanceMap = conn.prepareStatement(deleteDistanceMapQuery)) {
                psDistanceMap.setInt(1, mapId);
                psDistanceMap.executeUpdate();
            }
        }
    }

    // Get the distance between two places
    public static Double getDistanceBetweenPlaces(String placeA, String placeB) throws SQLException {
        String query = "SELECT distance_place FROM distance_map WHERE (place_a = ? AND place_b = ?) OR (place_a = ? AND place_b = ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, placeA);
            ps.setString(2, placeB);
            ps.setString(3, placeB);
            ps.setString(4, placeA);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("distance_place");
                }
            }
        }
        return null; // Return null if no distance is found
    }

    // Get all unique locations
    public static List<String> getAllUniqueLocations() throws SQLException {
        String query = "SELECT DISTINCT place_a FROM distance_map UNION SELECT DISTINCT place_b FROM distance_map";
        List<String> locations = new ArrayList<>();

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String location = rs.getString(1);
                if (location != null && !location.isEmpty()) { // Avoid null or empty values
                    locations.add(location);
                }
            }
        }
        return locations;
    }

    // Update an existing distance map entry
    public static void updateDistance(DistanceMap distanceMap) throws SQLException {
        String sql = "UPDATE distance_map SET place_a = ?, place_b = ?, distance_place = ? WHERE map_id = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, distanceMap.getPlaceA());
            ps.setString(2, distanceMap.getPlaceB());
            ps.setDouble(3, distanceMap.getDistancePlace());
            ps.setInt(4, distanceMap.getMapId());
            ps.executeUpdate();
        }
    }
}
