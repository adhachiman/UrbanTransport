package servlet;

import DAO.VehicleDAO;
import DAO.DistanceMapDAO;
import model.Vehicle;
import model.DistanceMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/IndexServlet")
public class IndexServlet2 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Fetch all vehicles and routes from database
            List<Vehicle> vehicles = VehicleDAO.getAllVehicles();
            List<DistanceMap> distanceMaps = DistanceMapDAO.getAllDistances();

            // Pass data to index.jsp
            request.setAttribute("vehicles", vehicles);
            request.setAttribute("distanceMaps", distanceMaps);

            // Forward to JSP
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unexpected error occurred.");
        }
    }
}
